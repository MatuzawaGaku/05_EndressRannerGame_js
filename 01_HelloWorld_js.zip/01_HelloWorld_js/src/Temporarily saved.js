/*
var spriteA = cc.Sprite.create(res.drop01_png);
spriteA.setPosition(size.width / 4, size.height*/ 4);
this.addChild(spriteA);
var spriteB = cc.Sprite.create(res.drop02_png);
spriteB.setPosition(size.width *3/ 4, size.height / 4);
this.addChild(spriteB);
var spriteC = cc.Sprite.create(res.drop03_png);
spriteC.setPosition(size.width *3/ 4, size.height *3/ 4);
this.addChild(spriteC);
var spriteD = cc.Sprite.create(res.drop04_png);
spriteD.setPosition(size.width / 4, size.height *3/ 4);
this.addChild(spriteD);
var spriteE = cc.Sprite.create(res.drop05_png);
spriteE.setPosition(size.width / 2, size.height / 2);
this.addChild(spriteE);
*/
/*
var backgroundLayer = cc.Layer.extend({
    sprite: null,
    dropSpriteArray: null,
    dropArray: [res.drop01_png, res.drop02_png, res.drop03_png, res.drop04_png, res.drop05_png],
    ctor: function() {
        this._super();
        var size = cc.director.getWinSize();
        this.dropSpriteArray = new Array();
        var i=1;
        for(i=1;i<=5; i++){
          var drop01 = cc.Sprite.create(res.drop01_png);　
          drop01.setPosition(size.width * i / 6, size.height / 5);　
          this.addChild(drop01);
        }



        return true;
    },
});
*/
