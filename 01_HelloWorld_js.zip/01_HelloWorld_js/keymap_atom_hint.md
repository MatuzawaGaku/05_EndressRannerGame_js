##  atom keybindings
Markdownのプレービュー表示 : control + shift + M  
コメントアウト	：Ct：rl + /  
単語を選択　:Ctrl + D　：※入力ごとに同じ単語を選択  
単語の末尾に移動  :Alt + F  
単語の先頭に移動  :Alt + B  
行の末尾に移動	  :  
矩形選択        :Ctrl + Alt + 上矢印キー or 下矢印キー  
複数箇所選択    :	Ctrl + クリック  
インデントを一つ追加　:Ctrl + ]　※複数行もOK  
インデントを一つ削除　:Ctrl + [	※複数行もOK  
行の選択	:Ctrl + L  
行の削除	:Ctrl + Shift + K  
行ごと移動	：Ctrl + 上矢印キー or 下矢印キー  
行ごと下の行へコピー	：Ctrl + Shift + D  
行の下に空行を挿入	：Ctrl + Enter  
行の上に空行を挿入	：Ctrl + Shift + Enter  
画面を右に分割	：(Ctrl + K)+　一度指を話してから + 右矢印キー  
画面を下に分割	：(Ctrl + K)+　一度指を話してから + 下矢印キー  
分割画面（ペインという）間での移動：(Ctrl + K) + (Ctrl+矢印キー)
プロジェクトツリーにフォーカス：alt + ￥ (その後矢印キー上下で移動し、開きたいﾌｧｲﾙの上でEnterすると分割された画面でﾌｧｲﾙが開く)
画面を閉じる	Ctrl + W  
タブを閉じる  :ctrl-W  
タブを切り替える　:ctrl+tab
設定画面: ctrl+,  
スニペット表示:alt-Shift-S :頻繁に使うコードをショートカットキーで呼び出せる  
検索パネルを開く:ctrl+f
次を検索：F3
指定行に移動する：ctrl+g


## plugin の起動
git-plus      :Ctrl-Shift-H  :git-plusのパネルを表示させる  
Atom Beautify         :ctrl-alt-b　:　自動整形  
atom-html-preview     :ctrl-shift-H : htmlﾌｧｲﾙをプレビューしてくれる  

## git-plus Command
 :Ctrl-Shift-H  :git-plusのパネルを表示させる  
ctrl-Shift-A	 :カレントファイルを git add する  
ctrl-Shift-A P	:git add, commit, push まで行う  
ctrl-Shift-C	   :git commit  
ctrl-Shift-A c	:git add , commit まで行う  
ctrl-Shift-A a	:全てのファイルを git add と commit する  

## プラグイン　Browser Plus
open(開く)     :ctrl-alt-o	:git-controlと競合しているkeybind  
close(閉じる)  :ctrl+w (atomの閉じるコマンド)  
history（履歴） :ctrl-alt-h:  
openDevTool（開発ツール）:f12  
